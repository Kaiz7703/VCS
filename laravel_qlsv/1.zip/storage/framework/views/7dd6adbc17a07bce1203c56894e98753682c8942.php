

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>User Details</span>
                <?php if(Auth::id() !== $user->id): ?>
                    <a href="<?php echo e(route('messages.show', $user)); ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-comments me-1"></i> Send Message
                    </a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <h5><?php echo e($user->name); ?></h5>
                <p>Email: <?php echo e($user->email); ?></p>
                <p>Phone: <?php echo e($user->phone ?? 'Not set'); ?></p>
                <p>Role: <?php echo e(ucfirst($user->role->name)); ?></p>
                <?php if(Auth::user()->isTeacher() || Auth::id() === $user->id): ?>
                    <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-primary">Edit Profile</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_qlsv\resources\views/users/show.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Conversations</h5>
                </div>
                <div class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('messages.show', $user)); ?>" 
                           class="list-group-item list-group-item-action d-flex align-items-center">
                            <i class="fas fa-user-circle fa-2x me-3"></i>
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h6 class="mb-0"><?php echo e($user->name); ?></h6>
                                    <?php if($user->unread_count > 0): ?>
                                        <span class="badge bg-danger rounded-pill"><?php echo e($user->unread_count); ?></span>
                                    <?php endif; ?>
                                </div>
                                <small class="text-muted"><?php echo e(ucfirst($user->role->name)); ?></small>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="list-group-item text-center text-muted">
                            No conversations yet
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_qlsv\resources\views/messages/index.blade.php ENDPATH**/ ?>